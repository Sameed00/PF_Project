#include <iostream>
#include <string>
using namespace std;

// Base class
class LibraryMaterial {
protected:
    string title;
    string author;
    string isbn;
    string publicationDate;

public:
    LibraryMaterial(string t, string a, string i, string p)
        : title(t), author(a), isbn(i), publicationDate(p) {}

    virtual void borrow() {
        cout << title << " has been borrowed.\n";
    }

    virtual void return_item() {
        cout << title << " has been returned.\n";
    }

    virtual ~LibraryMaterial() {}
};

// Derived class: Book
class Book : public LibraryMaterial {
private:
    string genre;
    int pageCount;
    string language;

public:
    Book(string t, string a, string i, string p, string g, int pc, string lang)
        : LibraryMaterial(t, a, i, p), genre(g), pageCount(pc), language(lang) {}

    void read() {
        cout << "Reading " << title << " in " << language << ".\n";
    }

    void bookmark_page(int page) {
        cout << "Page " << page << " of " << title << " bookmarked.\n";
    }
};

// Derived class: Magazine
class Magazine : public LibraryMaterial {
private:
    int issueNumber;
    string publicationFrequency;

public:
    Magazine(string t, string a, string i, string p, int issue, string freq)
        : LibraryMaterial(t, a, i, p), issueNumber(issue), publicationFrequency(freq) {}

    void flip_through() {
        cout << "Flipping through " << title << ", Issue " << issueNumber << ".\n";
    }

    void subscribe() {
        cout << "Subscribed to " << title << ;
    }
};

// Derived class: DVD
class DVD : public LibraryMaterial {
private:
    int regionCode;
    string director;

public:
    DVD(string t, string a, string i, string p, int rc, string dir)
        : LibraryMaterial(t, a, i, p), regionCode(rc), director(dir) {}

    void play() {
    	
    }
};

int main() {
	
    Book book("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565", "1925", "Fiction", 180, "English");
    book.borrow();
    book.read();
    book.bookmark_page(45);

    Magazine magazine("National Geographic", "Various Authors", "0027-9358", "2024", 105, "Monthly");
    magazine.flip_through();
    magazine.subscribe();

    DVD dvd("Planet Earth II", "David Attenborough", "5051561042392", "2016", 2, "BBC");
    dvd.play();
    dvd.pause();

    return 0;
}

