const phoneNumbers = [];

function addPhoneNumber(phoneNumber) {
    phoneNumbers.push(phoneNumber);
    console.log(`Phone number ${phoneNumber} added to the list.`);
}

function removePhoneNumber(index) {
    if (index >= 0 && index < phoneNumbers.length) {
        const removedNumber = phoneNumbers.splice(index, 1);
        console.log(`${removedNumber} removed from the list.`);
    } else {
        console.log("Invalid index. Unable to remove phone number.");
    }
}

function displayPhoneNumbers() {
    if (phoneNumbers.length === 0) {
        console.log("No phone numbers in the list.");
    } else {
        console.log("Phone numbers in the list:");
        phoneNumbers.forEach((number, index) => {
            console.log(`${index}: ${number}`);
        });
    }
}

function clearPhoneNumbers() {
    phoneNumbers.length = 0;
    console.log("Phone number list cleared.");
}

function findPhoneNumber(phoneNumber) {
    const index = phoneNumbers.indexOf(phoneNumber);
    if (index !== -1) {
        console.log(`Phone number found at index ${index} : ${phoneNumber}.`);
    } else {
        console.log(`Phone number ${phoneNumber} not found in the list.`);
    }
}

addPhoneNumber("123-456-7890");
addPhoneNumber("987-654-3210");
addPhoneNumber("555-123-4567");

displayPhoneNumbers();

findPhoneNumber("123-456-7890");

removePhoneNumber(1);
displayPhoneNumbers();

clearPhoneNumbers();
